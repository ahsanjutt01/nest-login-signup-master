import { OrdersEntity } from './OrdersEntity';
import { EmployeesInfoEntity } from './EmployeesInfoEntity';

const entities = [EmployeesInfoEntity, OrdersEntity];

export default entities;