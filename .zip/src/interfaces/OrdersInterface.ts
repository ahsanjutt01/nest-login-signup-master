export interface OrdersInterface {
    id?: number;
    employee_id: number;
    order_amount: number;
}